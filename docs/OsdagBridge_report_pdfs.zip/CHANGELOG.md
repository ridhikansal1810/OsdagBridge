# Changelog

20 Nov 2026

The report files are in src/osdagbridge/core/reports/

Tables
Files: report_utils.py, report_generator.py, chap1.py to chap5.py, chap7.py, chap8.py, executive_summary.py

- Made the table headers repeat when a table goes to the next page
- Fixed wide tables going out of the margin
- Kept each girder's rows together so they don't get split between pages
- Gave the Bill of Materials table a proper caption

Live loads
Files: chap3.py

- Split the live load table into two, one for vehicles and one for footpath
- Gave each vehicle its own row with load, impact factor, braking load and eccentricity
- Changed braking load to 20% of each vehicle's load (none for fatigue, and SV only if it's selected)

Charts
Files: report_charts.py (new), chap5.py, chap7.py, report_generator.py

- Added utilization ratio bar charts with a red line at 1.0
- Added charts for steel, concrete and rebar quantities

Code
Files: styles.py (new), report_utils.py, report_generator.py, chap2.py to chap8.py, executive_summary.py, pyproject.toml, requirements.txt, docs/report_refactor_changes.md (new)

- Used PyLaTeX for the tables and figures and added it to the requirements
- Put most of the formatting in one styles.py file
- Removed some repeated code and cleaned up the helper functions
- Wrote a doc explaining the changes
